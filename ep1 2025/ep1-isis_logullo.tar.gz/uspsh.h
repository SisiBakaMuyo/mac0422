/* Isis Ardisson Logull 7577410 */

void config_terminal(char * terminal);

void le_comando(char **comando, char **parametros);

void executa_bin(char *path, char *parametros);

int executa_comando(char *comando, char *parametros);